const CART_KEY = 'ecommercesite_cart';

export function loadCart() {
	try {
		const raw = localStorage.getItem(CART_KEY);
		return raw ? JSON.parse(raw) : [];
	} catch {
		return [];
	}
}

export function saveCart(items) {
	try {
		localStorage.setItem(CART_KEY, JSON.stringify(items));
	} catch {
		// ignore
	}
}


