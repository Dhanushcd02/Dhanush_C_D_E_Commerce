import 'dotenv/config';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mongoose from 'mongoose';
import { Product } from '../src/models/Product.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function run() {
	const mongoUri = process.env.MONGODB_URI;
	if (!mongoUri) throw new Error('MONGODB_URI is not set');
	await mongoose.connect(mongoUri);
	console.log('Connected to MongoDB (seed)');

	const dataPath = path.join(__dirname, '../data/products.json');
	const raw = await readFile(dataPath, 'utf8');
	const products = JSON.parse(raw);

	await Product.deleteMany({});
	await Product.insertMany(products);
	console.log(`Inserted ${products.length} products`);

	await mongoose.disconnect();
	console.log('Disconnected');
}

run().catch((err) => {
	console.error(err);
	process.exit(1);
});


