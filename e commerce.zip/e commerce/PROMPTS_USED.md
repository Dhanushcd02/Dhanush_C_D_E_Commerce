# Prompts Used

## Code Generation
- **Project scaffolding**: “Build a full-stack MERN E-Commerce Website project named 'EcommerceSite' … create client/ and server/ folders … add README, TECHNICAL_ARCHITECTURE.md, and PROMPTS_USED.md.”
- **Backend API**: “Create Express server with routes: GET /api/products, GET /api/products/:id, optional POST /api/cart; connect to MongoDB Atlas via Mongoose.”
- **Data model & seed**: “Add Product model with name, description, price, image, category; create seed script with 5–10 sample products.”
- **Frontend**: “Create React app with React Router (Home, Product Details, Cart), Tailwind CSS styling, and a global cart state with Context + localStorage.”

## Documentation
- **Tech architecture**: “Generate TECHNICAL_ARCHITECTURE.md describing stack, folder structure, API routes, data flow, and cart state management.”
- **Deployment**: “Add deployment guide for Vercel (frontend) and Render/Railway (backend), including environment variables and CORS notes.”

## Database Setup
- **Seeding**: “Provide a seed script that reads sample products from JSON and inserts them into MongoDB Atlas using MONGODB_URI.”

Each of the above guided the structure, code, and documentation in this repository.


