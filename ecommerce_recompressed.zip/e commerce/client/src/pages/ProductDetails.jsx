import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useCart } from '../state/CartContext.jsx';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000';

export default function ProductDetails() {
	const { id } = useParams();
	const [product, setProduct] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState('');
	const { addToCart } = useCart();

	useEffect(() => {
		async function load() {
			try {
				setLoading(true);
				const res = await axios.get(`${API_BASE_URL}/api/products/${id}`);
				setProduct(res.data);
			} catch (err) {
				setError('Failed to load product');
			} finally {
				setLoading(false);
			}
		}
		load();
	}, [id]);

	if (loading) return <p>Loading...</p>;
	if (error) return <p className="text-red-600">{error}</p>;
	if (!product) return <p>Product not found</p>;

	return (
		<div className="grid md:grid-cols-2 gap-6">
			<img src={product.image} alt={product.name} className="w-full h-80 object-cover rounded" />
			<div>
				<h1 className="text-3xl font-bold mb-2">{product.name}</h1>
				<p className="text-gray-600 mb-4">{product.description}</p>
				<p className="text-blue-600 text-2xl font-bold mb-6">${product.price.toFixed(2)}</p>
				<button
					onClick={() => addToCart(product, 1)}
					className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
				>
					Add to Cart
				</button>
			</div>
		</div>
	);
}


