import { useCart } from '../state/CartContext.jsx';

export default function Cart() {
	const { state, removeFromCart, updateQuantity, clearCart } = useCart();
	const total = state.items.reduce((sum, item) => sum + item.price * item.quantity, 0);

	if (state.items.length === 0) {
		return <p>Your cart is empty.</p>;
	}

	return (
		<div>
			<h1 className="text-2xl font-bold mb-4">Your Cart</h1>
			<div className="space-y-4">
				{state.items.map((item) => (
					<div key={item._id || item.name} className="flex items-center gap-4 border p-3 rounded">
						<img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded" />
						<div className="flex-1">
							<p className="font-semibold">{item.name}</p>
							<p className="text-gray-600">${item.price.toFixed(2)}</p>
						</div>
						<div className="flex items-center gap-2">
							<button
								onClick={() => updateQuantity(item._id || item.name, Math.max(1, item.quantity - 1))}
								className="px-2 py-1 border rounded"
							>
								-
							</button>
							<span className="w-8 text-center">{item.quantity}</span>
							<button
								onClick={() => updateQuantity(item._id || item.name, item.quantity + 1)}
								className="px-2 py-1 border rounded"
							>
								+
							</button>
						</div>
						<button
							onClick={() => removeFromCart(item._id || item.name)}
							className="text-red-600 hover:underline ml-4"
						>
							Remove
						</button>
					</div>
				))}
			</div>
			<div className="mt-6 flex items-center justify-between">
				<p className="text-xl font-bold">Total: ${total.toFixed(2)}</p>
				<div className="flex items-center gap-3">
					<button onClick={clearCart} className="px-4 py-2 border rounded">
						Clear Cart
					</button>
					<button className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">Checkout</button>
				</div>
			</div>
		</div>
	);
}


