import { useEffect, useState } from 'react';
import axios from 'axios';
import ProductCard from '../components/ProductCard.jsx';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000';

export default function Home() {
	const [products, setProducts] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState('');

	useEffect(() => {
		async function load() {
			try {
				setLoading(true);
				const res = await axios.get(`${API_BASE_URL}/api/products`);
				setProducts(res.data);
			} catch (err) {
				setError('Failed to load products');
			} finally {
				setLoading(false);
			}
		}
		load();
	}, []);

	if (loading) return <p>Loading products...</p>;
	if (error) return <p className="text-red-600">{error}</p>;

	return (
		<div>
			<h1 className="text-2xl font-bold mb-4">Products</h1>
			<div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
				{products.map((p) => (
					<ProductCard key={p._id || p.name} product={p} />
				))}
			</div>
		</div>
	);
}


