import { createContext, useContext, useEffect, useMemo, useReducer } from 'react';
import { loadCart, saveCart } from '../utils/storage.js';

const CartContext = createContext(null);

const initialState = {
	items: [],
};

function cartReducer(state, action) {
	switch (action.type) {
		case 'INIT': {
			return { ...state, items: action.payload || [] };
		}
		case 'ADD_ITEM': {
			const { product, quantity } = action.payload;
			const id = product._id || product.name;
			const existing = state.items.find((i) => (i._id || i.name) === id);
			let items;
			if (existing) {
				items = state.items.map((i) =>
					(i._id || i.name) === id ? { ...i, quantity: i.quantity + quantity } : i
				);
			} else {
				items = [...state.items, { ...product, quantity }];
			}
			return { ...state, items };
		}
		case 'REMOVE_ITEM': {
			const id = action.payload;
			return { ...state, items: state.items.filter((i) => (i._id || i.name) !== id) };
		}
		case 'UPDATE_QUANTITY': {
			const { id, quantity } = action.payload;
			return {
				...state,
				items: state.items.map((i) => ((i._id || i.name) === id ? { ...i, quantity } : i)),
			};
		}
		case 'CLEAR': {
			return { ...state, items: [] };
		}
		default:
			return state;
	}
}

export function CartProvider({ children }) {
	const [state, dispatch] = useReducer(cartReducer, initialState);

	useEffect(() => {
		const stored = loadCart();
		dispatch({ type: 'INIT', payload: stored });
	}, []);

	useEffect(() => {
		saveCart(state.items);
	}, [state.items]);

	const value = useMemo(() => {
		function addToCart(product, quantity = 1) {
			dispatch({ type: 'ADD_ITEM', payload: { product, quantity } });
		}
		function removeFromCart(id) {
			dispatch({ type: 'REMOVE_ITEM', payload: id });
		}
		function updateQuantity(id, quantity) {
			dispatch({ type: 'UPDATE_QUANTITY', payload: { id, quantity } });
		}
		function clearCart() {
			dispatch({ type: 'CLEAR' });
		}
		return { state, addToCart, removeFromCart, updateQuantity, clearCart };
	}, [state]);

	return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
	const ctx = useContext(CartContext);
	if (!ctx) throw new Error('useCart must be used within CartProvider');
	return ctx;
}


