import { Link } from 'react-router-dom';
import { useCart } from '../state/CartContext.jsx';

export default function ProductCard({ product }) {
	const { addToCart } = useCart();
	return (
		<div className="border rounded-lg overflow-hidden bg-white flex flex-col">
			<Link to={`/product/${product._id || ''}`} className="block">
				<img src={product.image} alt={product.name} className="h-48 w-full object-cover" />
			</Link>
			<div className="p-4 flex-1 flex flex-col">
				<h3 className="font-semibold text-lg mb-1">{product.name}</h3>
				<p className="text-gray-600 text-sm line-clamp-2 mb-2">{product.description}</p>
				<div className="mt-auto flex items-center justify-between">
					<span className="text-blue-600 font-bold">${product.price.toFixed(2)}</span>
					<button
						onClick={() => addToCart(product, 1)}
						className="bg-blue-600 text-white px-3 py-1.5 rounded hover:bg-blue-700"
					>
						Add to Cart
					</button>
				</div>
			</div>
		</div>
	);
}


