export default function Footer() {
	return (
		<footer className="border-t bg-gray-50">
			<div className="container mx-auto px-4 py-6 text-sm text-gray-600 flex items-center justify-between">
				<p>&copy; {new Date().getFullYear()} EcommerceSite</p>
				<p>Built with React, Express, and MongoDB</p>
			</div>
		</footer>
	);
}


