import { Link, NavLink } from 'react-router-dom';
import { useCart } from '../state/CartContext.jsx';

export default function Navbar() {
	const { state } = useCart();
	const count = state.items.reduce((sum, item) => sum + item.quantity, 0);
	return (
		<header className="border-b bg-white">
			<div className="container mx-auto px-4 py-4 flex items-center justify-between">
				<Link to="/" className="text-xl font-bold">EcommerceSite</Link>
				<nav className="flex items-center gap-4">
					<NavLink to="/" className={({ isActive }) => isActive ? 'text-blue-600 font-medium' : 'text-gray-700'}>Home</NavLink>
					<NavLink to="/cart" className={({ isActive }) => isActive ? 'text-blue-600 font-medium' : 'text-gray-700'}>
						Cart ({count})
					</NavLink>
				</nav>
			</div>
		</header>
	);
}


