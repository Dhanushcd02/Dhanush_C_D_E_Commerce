## EcommerceSite — Technical Architecture

### Stack
- **Frontend**: React (Vite), React Router, Tailwind CSS
- **Backend**: Node.js, Express, Mongoose
- **Database**: MongoDB Atlas

### Folder Structure
```
EcommerceSite/
├─ client/                # React app (Vite)
│  ├─ src/
│  │  ├─ components/      # UI components (Navbar, Footer, ProductCard)
│  │  ├─ pages/           # Home, ProductDetails, Cart
│  │  ├─ state/           # CartContext (Context API)
│  │  ├─ utils/           # localStorage helpers
│  │  ├─ App.jsx
│  │  └─ main.jsx
│  ├─ index.html
│  ├─ index.css
│  ├─ env.example
│  └─ package.json
└─ server/                # Node/Express API
   ├─ src/
   │  ├─ lib/db.js        # Mongo connection
   │  ├─ models/Product.js
   │  ├─ routes/products.js
   │  ├─ routes/cart.js
   │  └─ index.js         # Express app
   ├─ seed/seed.js        # Seed script
   ├─ data/products.json  # Sample products
   └─ package.json
```

### API Routes
- `GET /api/products` — returns all products
- `GET /api/products/:id` — returns a product by id
- `POST /api/cart` — (optional) validates/echoes cart payload

### Data Model
`Product`:
- `name`: string (required)
- `description`: string (required)
- `price`: number (required)
- `image`: string (required)
- `category`: string (required)

### Data Flow
1) The frontend makes requests to the backend using `VITE_API_BASE_URL` (e.g., `http://localhost:5000` or deployed URL).
2) Backend resolves the request, queries MongoDB via Mongoose, and returns JSON responses.
3) Frontend renders product lists and details; users add items to the cart.
4) Cart state is retained globally in Context and persisted in `localStorage`.

### State Management (Cart)
- Implemented via **React Context API** with a reducer-based state.
- Actions: `INIT`, `ADD_ITEM`, `REMOVE_ITEM`, `UPDATE_QUANTITY`, `CLEAR`.
- On app load, `CartProvider` hydrates from `localStorage`; on changes, it saves back to `localStorage`.

### Sequence Diagram (High-Level)
```
User -> Frontend: Clicks "Products"
Frontend -> Backend: GET /api/products
Backend -> MongoDB: Query products
MongoDB -> Backend: Products array
Backend -> Frontend: JSON products
Frontend -> User: Render grid

User -> Frontend: Clicks Product
Frontend -> Backend: GET /api/products/:id
Backend -> MongoDB: Query by id
MongoDB -> Backend: Product
Backend -> Frontend: JSON product
Frontend -> User: Render details + Add to Cart

User -> Frontend: Add to Cart
Frontend: Update Context + localStorage
```

### Environment Variables
- Backend: `MONGODB_URI`, `PORT`
- Frontend: `VITE_API_BASE_URL`

### Security and CORS
- CORS enabled on backend. Restrict in production to known frontend domains.

### Deployment Notes
- Frontend: Vercel auto-detects Vite; set `VITE_API_BASE_URL` in project envs.
- Backend: Render/Railway as a Node service; set `MONGODB_URI` and (if needed) `PORT`. Ensure CORS allows the frontend origin.


