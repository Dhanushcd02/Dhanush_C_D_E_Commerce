EcommerceSite — MERN E‑Commerce Website

Overview
EcommerceSite is a full-stack MERN application that lets users explore products, view details, and manage a shopping cart. It features a responsive React frontend styled with Tailwind CSS and a lightweight Node/Express backend connected to MongoDB Atlas.

Monorepo Layout
- client/ — React + Vite + Tailwind frontend
- server/ — Node.js + Express + Mongoose backend

Quick Start
Prerequisites
- Node.js 18+
- npm or yarn
- MongoDB Atlas account

Environment Setup
Copy the example env files and fill in values:

```bash
cp server/.env.example server/.env
cp client/.env.example client/.env
```

Server (Backend)
```bash
cd server
npm install
# Seed database with sample products (requires valid MONGODB_URI in .env)
npm run seed
# Start dev server with hot reload
npm run dev
```
The backend runs on http://localhost:5000 by default.

Client (Frontend)
```bash
cd client
npm install
npm run dev
```
The frontend runs on http://localhost:5173 by default. Ensure `VITE_API_BASE_URL` in `client/.env` points to your backend, e.g.:
```
VITE_API_BASE_URL=http://localhost:5000
```

Key Features
- Product listing and details pages
- Cart with global state via React Context
- Cart persistence using localStorage
- Clean, responsive UI with Tailwind CSS

Tech Stack
- Frontend: React, React Router, Vite, Tailwind CSS
- Backend: Node.js, Express, Mongoose
- Database: MongoDB Atlas

Scripts
Client
- dev — start Vite dev server
- build — build for production
- preview — preview production build

Server
- dev — start with nodemon
- start — start server
- seed — seed MongoDB with sample products

Deployment
Frontend (Vercel)
1) Set environment variable in Vercel Project Settings:
   - VITE_API_BASE_URL=https://your-backend.example.com
2) Deploy the `client/` directory (Vercel detects Vite automatically).

Backend (Render or Railway)
1) Create a new Web Service using the `server/` directory.
2) Set environment variables:
   - PORT=5000 (or provided by platform)
   - MONGODB_URI=your-mongodb-atlas-connection-string
3) Build/Start Command (Render/Railway):
   - Build: npm install
   - Start: npm start
4) Ensure CORS allows your frontend domain.

Documentation
- TECHNICAL_ARCHITECTURE.md — stack, structure, API routes, data flow, state management
- PROMPTS_USED.md — list of prompts used to generate code, docs, and setup

License
MIT


